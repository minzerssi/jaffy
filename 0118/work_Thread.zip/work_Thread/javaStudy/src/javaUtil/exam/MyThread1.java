package javaUtil.exam;

public class MyThread1 extends Thread {
	//테스트를 위해 String필드를 하나 선언
	String str;
	// 생성할 때부터 받아 들일 수 있게 생성자 하나 지정
	public MyThread1(String str) {
		this.str = str;
	}
	
	
	@Override
	public void run() {
		//머든 수행하고 싶은걸 하면 됨
		for(int i=0; i<10; i++) {
			System.out.println(str);
			
			try {
				Thread.sleep((int)(Math.random()*1000));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
