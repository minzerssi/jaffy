package javaUtil.exam;

public class ThreadExam {

	public static void main(String[] args) {
		MyThread1 t1 = new MyThread1("*");
		MyThread1 t2 = new MyThread1("-");
		
		//start메소드를 호출해야지 쓰레드가 수행함
		t1.start(); // 수행 흐름이 2개 main과 run
		t2.start(); // 수행 흐름이 3개
		
		
		//모든 쓰레드가 끝나야지 프로그램이 종류됨
		System.out.println("main end!!!!!");
	}

}
