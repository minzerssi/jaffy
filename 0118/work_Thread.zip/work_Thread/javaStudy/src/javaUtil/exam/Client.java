package javaUtil.exam;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) throws IOException {
		Socket socket = null;
		
		BufferedReader in = null;
		BufferedReader in2 = null;
		PrintWriter out = null;
		InetAddress ia = null;
		
		
			try {
				ia = InetAddress.getByName("서버주소 입력");
				socket = new Socket(ia, 8000);
				in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				in2 = new BufferedReader(new InputStreamReader(System.in));
				out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())));
				
				System.out.println(socket.toString());
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
	            System.out.print("서버로 보낼 메세제 : ");
	            String data = in2.readLine();            //키보드로부터 입력
	            out.println(data);                        //서버로 데이터 전송
	            out.flush();

	            String str2 = in.readLine();            //서버로부터 되돌아오는 데이터 읽어들임
	            System.out.println("서버로부터 되돌아온 메세지 : " + str2);
	            socket.close();
	            
	        }catch(IOException e) {}
		
		
	}

}
