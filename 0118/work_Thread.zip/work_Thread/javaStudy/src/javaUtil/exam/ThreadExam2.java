package javaUtil.exam;

public class ThreadExam2 {

	public static void main(String[] args) {
		MyThread2 t1 = new MyThread2("*");
		MyThread2 t2 = new MyThread2("-");
		
		// thread를 상속받은게 아니라 start메소드를 쓸 수 없다.
		Thread thread1 = new Thread(t1);//Runnable 상속받은 함수를 넣어라
		Thread thread2 = new Thread(t2);
		
		thread1.start();
		
		thread2.start();
		
		System.out.println("main end!!!!!");
	}

}
